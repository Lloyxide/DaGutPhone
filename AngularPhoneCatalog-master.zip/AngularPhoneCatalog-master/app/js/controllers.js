'use strict';

/* Controllers */

var phonecatControllers = angular.module('phonecatControllers', []);

phonecatControllers.controller('PhoneListCtrl', ['$scope', 'Phone',
  function($scope, Phone) {
    $scope.phones = Phone.query();
    $scope.orderProp = 'age';
  }]);

phonecatControllers.controller('PhoneDetailCtrl', ['$scope', '$routeParams', 'Phone',
  function($scope, $routeParams, Phone) {
    $scope.phone = Phone.get({phoneId: $routeParams.phoneId}, function(phone) {
      $scope.mainImageUrl = phone.images[0];
    });

    $scope.setImage = function(imageUrl) {
      $scope.mainImageUrl = imageUrl;
    };
  }]);

 phonecatControllers.controller('ContactCtrl', ['$scope', '$http', 
  function($scope, $http) {
   $scope.envoieMail = function(){
      var url = "https://api.mailgun.net/v3/sandbox960a534028f14cbbaf82d996ff2dae26.mailgun.org/messages";
        var dataJSON = {
            from: "Wow@ezpz.com",
            to: $scope.mail,
            subject: "Bonjour, " + $scope.nom + " !",
            text: $scope.text,
            multipart: true
        }

        var req = {
            method : 'POST',
            url: url,
            headers : {
                'content-type': 'application/x-www-form-urlencoded',
                'Authorization': 'Basic YXBpOmtleS0yMzJmYzAwMWJlYmY3YTdiMTU0ZGNiZTgzMjM3MzA2MQ=='
            },
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj)
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                return str.join("&");
            },
            data: dataJSON
        }
        $http(req).then(function(data){
            console.log(data);
        }, function(data){
            console.log(data);
        })
	};
  }]);